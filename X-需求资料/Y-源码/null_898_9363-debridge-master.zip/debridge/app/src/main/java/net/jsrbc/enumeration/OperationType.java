package net.jsrbc.enumeration;

/**
 * Created by ZZZ on 2017-12-12.
 */
public enum OperationType {
    ADD, EDIT, COPY
}
